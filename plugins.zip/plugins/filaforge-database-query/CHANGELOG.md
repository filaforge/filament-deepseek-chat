# Changelog

All notable changes to `filaforge/database-query` will be documented in this file.

## v0.1.0 - 2025-08-13
- Initial public release for Filament v4.
- SQL Database Query page (read-only SELECT support).
# Changelog

## 1.0.0 - Initial release

- initial release