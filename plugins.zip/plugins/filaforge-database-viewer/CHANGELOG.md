# Changelog

All notable changes to `filaforge/database-viewer` will be documented in this file.

## v0.1.0 - 2025-08-13
- Initial public release for Filament v4.
- Database Viewer page with table browser and data preview.
# Changelog

## 1.0.0 - Initial release

- initial release