# Changelog

All notable changes to `filaforge/deepseek-chat` will be documented in this file.

## v0.1.0 - 2025-08-13
- Initial public release for Filament v4.
- Deepseek Chat page and settings.
# Changelog

## 1.0.0 - Initial release

- initial release