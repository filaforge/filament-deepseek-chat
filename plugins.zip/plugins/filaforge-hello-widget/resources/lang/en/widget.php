<?php

return [
    'title' => 'Hello Widget',
    'description' => 'This is a simple example widget provided by a plugin.',
];
