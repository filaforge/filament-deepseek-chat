<?php

return [
    'title' => 'System Monitor',
];
