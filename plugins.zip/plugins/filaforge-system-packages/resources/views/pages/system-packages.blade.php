<x-filament::page>
    <x-filament::section>
        <x-slot name="heading">Installed Composer Packages</x-slot>
        {{ $this->table }}
    </x-filament::section>
</x-filament::page>

