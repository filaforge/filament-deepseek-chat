# Changelog

All notable changes to `filaforge/system-tools` will be documented in this file.

## v0.1.0 - 2025-08-13
- Initial public release for Filament v4.
- System Tools page with handy utilities.
# Changelog

## 1.0.0 - Initial release

- initial release