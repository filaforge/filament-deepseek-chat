# Changelog

All notable changes to `filaforge/terminal-console` will be documented in this file.

## v0.1.0 - 2025-08-13
- Initial public release for Filament v4.
- Terminal Console page with allowlisted commands and xterm.js UI.
# Changelog

## 1.0.0 - Initial release

- initial release