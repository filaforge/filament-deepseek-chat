<?php

namespace Filaforge\UserManager\Resources\UserResource\Pages;

use Filaforge\UserManager\Resources\UserResource;
use Filament\Resources\Pages\EditRecord;

class EditUser extends EditRecord
{
    protected static string $resource = UserResource::class;
}


