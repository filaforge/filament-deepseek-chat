<?php

namespace VendorName\Skeleton;

class Skeleton {}
