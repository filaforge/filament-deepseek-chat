# Changelog

All notable changes to `filaforge/api-explorer` will be documented in this file.

## v0.1.0 - 2025-08-13
- Initial public release for Filament v4.
- API Explorer page for testing HTTP requests.
