<?php

return [
    // Placeholder translations. Add your package translations here.
];
