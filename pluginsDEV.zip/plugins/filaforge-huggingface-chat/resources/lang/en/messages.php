<?php

return [
	'title' => 'Hugging Face Chat',
	'settings' => 'Hugging Face Settings',
];






