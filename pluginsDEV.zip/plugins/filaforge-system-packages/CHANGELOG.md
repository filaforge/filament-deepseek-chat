# Changelog

All notable changes to `filaforge/system-packages` will be documented in this file.

## v0.1.0 - 2025-08-13
- Initial public release for Filament v4.
- Composer Packages resource and legacy redirect page.
# Changelog

## 1.0.0 - Initial release

- initial release