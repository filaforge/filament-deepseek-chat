# Changelog

All notable changes to `filaforge/system-widget` will be documented in this file.

## v0.1.0 - 2025-08-13
- Initial public release for Filament v4.
- System Monitor dashboard widget (namespaced to avoid collisions).
# Changelog

## 1.0.0 - Initial release

- initial release