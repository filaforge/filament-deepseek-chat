<x-filament::page>
    <x-filament::section>
        {{ $this->form }}
    </x-filament::section>
</x-filament::page>
