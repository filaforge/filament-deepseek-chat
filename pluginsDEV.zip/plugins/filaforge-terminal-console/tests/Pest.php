<?php

uses(Filaforge\TerminalConsole\Tests\TestCase::class)->in(__DIR__);
