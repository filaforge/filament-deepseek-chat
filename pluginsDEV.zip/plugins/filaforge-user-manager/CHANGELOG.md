# Changelog

All notable changes to `filaforge/user-manager` will be documented in this file.

## v0.1.0 - 2025-08-13
- Initial public release for Filament v4.
- Users resource for CRUD.
# Changelog

## 1.0.0 - Initial release

- initial release