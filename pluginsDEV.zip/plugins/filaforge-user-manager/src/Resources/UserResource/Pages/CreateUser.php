<?php

namespace Filaforge\UserManager\Resources\UserResource\Pages;

use Filaforge\UserManager\Resources\UserResource;
use Filament\Resources\Pages\CreateRecord;

class CreateUser extends CreateRecord
{
    protected static string $resource = UserResource::class;
}


