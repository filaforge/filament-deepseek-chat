
<div  onclick="Livewire.dispatch('closeWireChatModal')">
    {{ $slot }}
</div>
