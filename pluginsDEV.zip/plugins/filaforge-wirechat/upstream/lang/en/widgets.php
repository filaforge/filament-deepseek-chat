<?php

return [

    // chat component
    'wirechat' => [
        'messages' => [
            'welcome' => 'Select a conversation to start messaging',

        ],
    ],
];
