<?php

return [

    // chat component
    'chat' => [
        'messages' => [
            'welcome' => 'Mesajlaşmaya başlamak için bir sohbet seçin',
        ],
    ],
];
