<?php

declare(strict_types=1);

return [
    'button_label' => 'Quick Create',
];
