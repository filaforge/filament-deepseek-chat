<?php

// config for VendorName/Skeleton
return [

];
