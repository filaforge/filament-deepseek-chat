<?php

// translations for VendorName/Skeleton
return [
    //
];
