<x-filament::page>
    <div class="h-[80vh]">
        @livewire('wirechat::chat')
    </div>
</x-filament::page>