<x-filament::page>
    <h2 class="text-xl font-bold mb-4">My Profile</h2>
    <p>This is a placeholder for user profile details.</p>
</x-filament::page>