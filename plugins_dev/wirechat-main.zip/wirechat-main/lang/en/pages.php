<?php

return [

    // chat component
    'chat' => [
        'messages' => [
            'welcome' => 'Select a conversation to start messaging',

        ],
    ],
];
