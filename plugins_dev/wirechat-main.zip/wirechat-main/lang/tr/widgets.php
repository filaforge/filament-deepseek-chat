<?php

return [

    // chat component
    'wirechat' => [
        'messages' => [
            'welcome' => 'Mesajlaşmaya başlamak için bir sohbet seçin',
        ],
    ],
];
