        
 <div x-cloak wire:loading.delay.class.remove="hidden"
 wire:target="search"class="hidden transition-all duration-300 ">
 <x-wirechat::loading-spin />
</div>