<?php

namespace Namu\WireChat\Enums;

enum GroupType: string
{
    case PRIVATE = 'private';
    case PUBLIC = 'public';

}
